from PySide6.QtCore import QSize

from src.gesture_assistant.ui.camera_view import CameraView
from src.gesture_assistant.ui.main_window import MainWindow


def test_camera_view_preserves_aspect(qapp):
    view = CameraView()
    view.resize(1000, 500)
    rect = view._scaled_target_rect(QSize(640, 480))
    assert abs(rect.width() / rect.height() - 640 / 480) < 0.01
    assert rect.width() <= view.width()
    assert rect.height() <= view.height()
    view.close()


def test_diagnostic_panel_constructs_without_camera(qapp):
    window = MainWindow()
    assert window._worker is None
    assert "Gest" in window._diagnostic_label.text()
    assert window._start_button.isEnabled()
    window.close()


def test_actions_start_paused_and_no_executor_is_running(qapp):
    window = MainWindow()

    try:
        assert window._worker is None
        assert window._runtime.safety.paused
        assert window._runtime.executor.dry_run
        assert not window._runtime.executor.handlers
        assert not window._runtime.is_running

        window._toggle_actions_pause()

        assert window._runtime.safety.paused
        assert not window._runtime.is_running
        assert "Najpierw uruchom kamerę" in window._error_label.text()

        window._stop_analysis()

        assert window._runtime.safety.paused

    finally:
        window.close()
