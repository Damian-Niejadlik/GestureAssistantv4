"""Testy jednostkowe GestureAssistant."""
