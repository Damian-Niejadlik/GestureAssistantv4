"""Narzędzia pomocnicze GestureAssistant."""
