"""Interfejs graficzny GestureAssistant."""
